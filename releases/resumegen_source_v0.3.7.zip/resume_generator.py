import json
from google import genai
from google.genai.errors import APIError

# --- VERSIONING ---
VERSION_MAJOR = 0
VERSION_MINOR = 1 # MANUAL UPDATE: Minor version incremented for Release 0.3.7
CHANGELOG = [
    "Starting at 0.1, after re-initializing log."
]
# --- END VERSIONING ---

def generate_seven_resumes_html(api_key, resume_text, user_answers):
    """
    Connects to the Gemini API and generates a single HTML file containing
    seven tailored resumes based on the input text and user constraints.
    """
    if not api_key:
        print("Error: API Key is missing. Cannot generate content.")
        return None

    try:
        client = genai.Client(api_key=api_key)
    except Exception as e:
        print("Error initializing Gemini client with provided key.")
        print(f"Details: {e}")
        return None

    # 1. Define the System Instruction for Structured Output
    system_instruction = (
        "You are an expert Executive Resume Architect. Your sole task is to generate "
        "a single, complete HTML document containing seven distinct, tailored resume "
        "versions based on the provided inputs. You MUST strictly adhere to the "
        "constraints, technical facts, and formatting rules provided."
    )

    # 2. Compile the Context and Instructions into a Detailed Prompt
    prompt_template = """
    GOAL: Generate a single, comprehensive HTML file that contains SEVEN distinct resume versions.
    The HTML must be perfectly structured to display correctly in a web browser and be copy-paste ready for Microsoft Word.

    --- INPUT DATA ---
    1. CURRENT RESUME TEXT:
    {resume}

    2. USER STRATEGIC ANSWERS (Use these to create and quantify achievements):
    {answers}
    
    --- REQUIRED OUTPUT STRUCTURE ---
    1. The final output must be ONE single, complete HTML code block (from <!DOCTYPE html> to </html>).
    2. The HTML must contain a Table of Contents (TOC) with anchor links to all 7 sections.
    3. All bolded text must use the HTML <strong> tag, NOT Markdown **.
    4. The 7 required resumes are:
        a. 1-Page Summary
        b. Managerial Track (Startup Focus)
        c. Managerial Track (Established Company Focus)
        d. Architect Track (Startup Focus)
        e. Architect Track (Established Company Focus)
        f. Principal/Distinguished Track (Startup Focus - Managerial Blend)
        g. Principal/Distinguished Track (Established Company Focus - Managerial Blend)
    
    CRITICAL INSTRUCTIONS FOR RESUME CONTENT:
    - Target Domain: Semiconductor, High-Performance Infrastructure, and High-Volume Consumer.
    - Quantified Metrics MUST BE USED (as derived from user input):
        - Team size: 4-8 engineers.
        - Product Scope: Two distinct product lines on two separate occasions.
        - Cost Savings: Hundreds of thousands of dollars (from M4 migration).
        - Program Success: On-time launch of New Radio product for Milan Metro station.
        - Quality/Process: 2x increase in code test coverage.
        - Technical Performance: ~10% latency/performance improvement.
        - Semiconductor Expertise: First Silicon Bring-up, AI data-center efficiency enablement.
    
    Generate the full HTML code now, ensuring the layout is clean for professional resumes.
    """

    full_prompt = prompt_template.format(
        resume=resume_text,
        answers=json.dumps(user_answers, indent=2)
    )
    
    print("Generating resumes via Gemini API... this may take 30-60 seconds.")

    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash', 
            contents=full_prompt,
            config=genai.types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.4
            )
        )
        return response.text

    except APIError as e:
        print(f"\n--- API Error ---")
        print(f"An API error occurred. Check your API key or permissions.")
        print(f"Details: {e}")
        return None
    except Exception as e:
        print(f"\n--- General Error ---")
        print(f"An unexpected error occurred: {e}")
        return None

# --- CONSTANTS FOR EXECUTION ---
RESUME_TEXT = """
--- PAGE 1 ---
GREG SCAFFIDI
(512) 766-3736 | sgscaffidi3@gmail.com | Austin, TX | linkedin.com/in/sgscaffidi3
[... PASTE THE CANDIDATE'S FULL RESUME TEXT HERE ...]
"""

USER_ANSWERS = {
    "Primary_Domain": "Semiconductors, High-Performance Infrastructure (DSP, FPGA, Embedded Linux/Yocto)",
    "Preferred_Track_for_Principal": "Managerial Track (People & Strategy), blending technical depth with leadership.",
    "Target_Culture": "Open to both Startup and Established Corporations, requiring two versions of each senior resume.",
    "Quantified_Team_Size": "5-8 direct/functional reports.",
    "Quantified_Product_Scope": "2 distinct product lines on 2 occasions.",
    "Quantified_Performance_Metric": "Improved system latency/performance by ~10%; 2x code test coverage.",
    "Quantified_Business_Metric": "Achieved cost savings in the hundreds of thousands of dollars.",
    "Key_Achievement_1": "Program turnaround resulting in on-time launch for Milan Metro station.",
    "Key_Achievement_2": "Enabled new optical networking DSP chip for AI data-center efficiency."
}

if __name__ == '__main__':
    print(f"This file is a module. Run cli.py instead. Version: {VERSION_MAJOR}.{VERSION_MINOR}.{len(CHANGELOG)}")