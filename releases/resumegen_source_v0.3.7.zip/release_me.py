import os
import zipfile
import datetime
import sys

# Import all modules to access their versioning fields and ensure they are loaded
try:
    import cli
    import env_manager
    import app_setup
    import resume_generator
except ImportError as e:
    print(f"Error importing modules: {e}")
    print("Please ensure all source files (cli.py, env_manager.py, app_setup.py, resume_generator.py) are in the same directory.")
    sys.exit(1)

def calculate_release_version():
    """Calculates the MAJOR.MINOR.PATCH version based on project rules."""
    
    # Major version is hardcoded in cli.py
    major = cli.APP_VERSION_MAJOR
    
    # Minor version is the sum of all module minor versions
    minor = (
        env_manager.VERSION_MINOR +
        app_setup.VERSION_MINOR +
        resume_generator.VERSION_MINOR
    )
    
    # Patch version is the sum of all changelog lengths
    patch = (
        len(cli.APP_CHANGELOG) +
        len(env_manager.CHANGELOG) +
        len(app_setup.CHANGELOG) +
        len(resume_generator.CHANGELOG)
    )

    return f"{major}.{minor}.{patch}"

def generate_release_notes_html(version):
    """Generates an HTML document containing all changelogs."""
    
    date_str = datetime.datetime.now().strftime("%Y-%m-%d")
    project_name = "Tailored Resume Generator"
    
    # Dictionary of modules and their changelogs
    modules = {
        "cli.py (Main Application)": (cli.APP_VERSION_MAJOR, cli.APP_CHANGELOG, cli.calculate_app_version().split('.')[1]),
        "env_manager.py (API Key Management)": (env_manager.VERSION_MAJOR, env_manager.CHANGELOG, env_manager.VERSION_MINOR),
        "app_setup.py (Setup Flow)": (app_setup.VERSION_MAJOR, app_setup.CHANGELOG, app_setup.VERSION_MINOR),
        "resume_generator.py (Core Logic)": (resume_generator.VERSION_MAJOR, resume_generator.CHANGELOG, resume_generator.VERSION_MINOR)
    }

    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{project_name} Release Notes v{version}</title>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; margin: 40px; color: #333; }}
            h1 {{ color: #004d40; border-bottom: 3px solid #004d40; padding-bottom: 10px; }}
            h2 {{ color: #00796b; border-bottom: 1px solid #00796b; margin-top: 30px; }}
            h3 {{ color: #009688; margin-top: 20px; }}
            ul {{ list-style-type: disc; margin-left: 20px; }}
            li {{ margin-bottom: 5px; }}
            .metadata {{ background: #e0f2f1; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
            .metadata p {{ margin: 5px 0; }}
            .changelog-entry {{ margin-left: 20px; }}
        </style>
    </head>
    <body>
        <h1>{project_name} - Release v{version}</h1>
        
        <div class="metadata">
            <p><strong>Release Date:</strong> {date_str}</p>
            <p><strong>Version:</strong> {version}</p>
            <p>This is a major release focused on modularity (MINOR version change) and resolving API quota issues. All previous development changes have been aggregated into this single release.</p>
        </div>

        <h2>I. Component Changelogs</h2>
    """

    for name, (major, changelog, minor) in modules.items():
        patch = len(changelog)
        component_version = f"{major}.{minor}.{patch}"
        
        html_content += f"<h3>{name} (v{component_version})</h3>"
        html_content += "<ul>"
        
        for i, entry in enumerate(changelog):
            html_content += f"<li class='changelog-entry'><strong>{i+1}.</strong> {entry}</li>"
        
        html_content += "</ul>"

    html_content += """
        <p style="margin-top: 40px; text-align: center; color: #777;">End of Release Notes</p>
    </body>
    </html>
    """
    
    filename = f"Release_Notes_v{version}.html"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html_content)
        
    return filename

def package_source_files(version):
    """Creates a ZIP file of all core Python source files."""
    
    source_files = ['cli.py', 'env_manager.py', 'app_setup.py', 'resume_generator.py', 'release_me.py']
    zip_filename = f"resumegen_source_v{version}.zip"
    
    try:
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
            for file_to_add in source_files:
                if os.path.exists(file_to_add):
                    zf.write(file_to_add)
                else:
                    print(f"Warning: Source file not found, skipping: {file_to_add}")
        return zip_filename
    except Exception as e:
        print(f"Error creating ZIP file: {e}")
        return None

if __name__ == '__main__':
    print("--- Project Release Tool ---")
    
    # 1. Calculate the version
    release_version = calculate_release_version()
    print(f"Calculated Release Version: {release_version}")
    
    # 2. Generate the HTML release notes
    html_file = generate_release_notes_html(release_version)
    print(f"✅ Release Notes saved to: {html_file}")

    # 3. Package the source files
    zip_file = package_source_files(release_version)
    if zip_file:
        print(f"✅ Source files packaged to: {zip_file}")
    
    print("\nRelease operation complete. You can now commit the updated Python files and the new release files (HTML and ZIP)!")